function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (email === "123@gmail.com" && password === "1234") {
    
    window.location.href = "home.html"; // 👈 HOME PAGE
  } else {
    alert("Wrong Email or Password");
  }
}